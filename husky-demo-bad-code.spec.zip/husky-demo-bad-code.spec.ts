import { test, expect } from '@playwright/test';

/**
 * ДЕМОНСТРАЦІЙНИЙ ФАЙЛ З НАВМИСНИМИ ПОМИЛКАМИ
 *
 * Цей файл створено спеціально для демонстрації роботи Husky pre-commit hook.
 * Файл містить навмисні помилки форматування та ESLint, щоб показати студентам,
 * як автоматично працюють інструменти якості коду перед комітом.
 *
 * Помилки в цьому файлі:
 * 1. Помилки форматування (Prettier виправить автоматично)
 * 2. Помилки ESLint (ESLint виправить або покаже помилки)
 */

// Помилка: використання var замість const/let (ESLint: prefer-const, no-var)
var pageUrl = 'https://example.com';

// Помилка: подвійні лапки замість одинарних (Prettier виправить)
var title = 'Example Domain';

// Помилка: невикористана змінна (ESLint: no-unused-vars)
var unusedVariable = 'Це не використовується';

test.describe('Демонстрація помилок', () => {
  // Помилка: неправильні відступи та форматування
  test('має відкрити сторінку', async ({ page }) => {
    // Помилка: подвійні лапки
    await page.goto('https://example.com');

    // Помилка: неправильні пробіли та форматування
    await expect(page).toHaveTitle(/Example Domain/);

    // Помилка: var замість const
    var heading = page.locator('h1');
    await expect(heading).toBeVisible();
  });

  // Помилка: неправильне форматування функції
  test('має перевірити елементи', async ({ page }) => {
    await page.goto(pageUrl);

    // Помилка: невикористана змінна
    var element = page.locator('p');

    // Помилка: неправильні пробіли
    await expect(page.locator('h1')).toBeVisible();
  });

  // Помилка: відсутні крапки з комою (Prettier додасть)
  test('має зробити скріншот', async ({ page }) => {
    await page.goto(pageUrl);

    // Помилка: неправильне форматування об'єкта
    await page.screenshot({ path: 'screenshot.png', fullPage: true });
  });

  // Помилка: var замість const, невикористана змінна
  test('має знайти посилання', async ({ page }) => {
    await page.goto(pageUrl);

    // Помилка: var замість const
    var link = page.locator('a[href*="iana"]');

    // Помилка: невикористана змінна
    var linkText = await link.textContent();

    await expect(link).toBeVisible();
  });
});

// Помилка: невикористана функція (ESLint може показати попередження)
function helperFunction() {
  return 'Це не використовується';
}
